import streamlit as st

movies = ["Inception","Interstellar","Avatar","Titanic","The Dark Knight","Joker"]

recommendations = {
    "Inception": ["Interstellar", "The Dark Knight", "Joker"],
    "Interstellar": ["Inception", "Avatar", "Titanic"],
    "Avatar": ["Titanic", "Interstellar", "Joker"],
    "Titanic": ["Avatar", "Interstellar", "The Dark Knight"],
    "The Dark Knight": ["Inception", "Joker", "Interstellar"],
    "Joker": ["The Dark Knight", "Inception", "Titanic"]
}

st.title("Movie Recommendation System")
selected_movie = st.selectbox("Choose a Movie", movies)

if st.button("Recommend"):
    st.subheader("Recommended Movies")
    for movie in recommendations[selected_movie]:
        st.write("✅", movie)
