# Movie Recommendation System

## Overview
A simple Movie Recommendation System built using Python and Streamlit.

## Technologies Used
- Python
- Streamlit
- Pandas
- NumPy
- Scikit-learn

## Run
pip install -r requirements.txt
streamlit run app.py
